<?php

return array(
    'code' => 'BDT',
    'sign' => 'taka',
	'iso4217' => '50',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Bangladeshi taka',
    'name' => array(
        '৳',
    ),
    'frac_name' => array(
        'poisha',
    )
);